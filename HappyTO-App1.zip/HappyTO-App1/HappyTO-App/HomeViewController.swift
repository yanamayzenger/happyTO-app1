import UIKit

class HomeViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var dayLabel: UILabel!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var dayPicker: UIPickerView!
    @IBOutlet weak var backgroundImageView: UIImageView!

    var deals: [RestaurantDeal] = []
    let daysOfWeek = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]

    override func viewDidLoad() {
        super.viewDidLoad()
        print("viewDidLoad called") // Debugging statement
        tableView.delegate = self
        tableView.dataSource = self
        dayPicker.delegate = self
        dayPicker.dataSource = self

        // Display deals for the current day when the app loads
        displayDeals(for: currentDay())
    }

    // Determine the current day of the week
    func currentDay() -> String {
        let date = Date()
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "EEEE"
        return dateFormatter.string(from: date)
    }

    // Display deals based on the selected day
    func displayDeals(for day: String) {
        print("displayDeals called for day: \(day)")
        dayLabel.text = day
        deals = loadDeals(for: day.lowercased())
        print("Deals for \(day): \(deals)")
        tableView.reloadData()
    }

    // Load deals from JSON file based on the day of the week
    func loadDeals(for day: String) -> [RestaurantDeal] {
        guard let path = Bundle.main.path(forResource: "happyHours", ofType: "json") else {
            print("JSON file not found.")
            return []
        }
        
        print("JSON file path: \(path)")
        
        let url = URL(fileURLWithPath: path)
        do {
            let data = try Data(contentsOf: url)
            let jsonResult = try JSONSerialization.jsonObject(with: data, options: .mutableContainers)
            if let jsonDict = jsonResult as? [String: [[String: String]]] {
                let dayDeals = jsonDict[day] ?? []
                print("Loaded deals for \(day): \(dayDeals)")
                return dayDeals.map { RestaurantDeal(json: $0) }
            }
        } catch {
            print("Error loading JSON data: \(error)")
        }
        return []
    }

    // MARK: - UIPickerViewDataSource

    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }

    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return daysOfWeek.count
    }

    // MARK: - UIPickerViewDelegate

    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return daysOfWeek[row]
    }

    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        displayDeals(for: daysOfWeek[row])
    }

    // MARK: - UITableViewDataSource

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        print("Number of deals: \(deals.count)") // Debugging statement
        return deals.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "DealCell", for: indexPath) as! DealCell
        let deal = deals[indexPath.row]
        print("Configuring cell for deal: \(deal)") // Debugging statement
        cell.configure(with: deal)
        return cell
    }
}
