//
//  ViewController.swift
//  HappyTO-App
//
//  Created by Yana Mayzenger on 13/07/2024.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

